﻿using UnityEngine;
using System.Collections;

public class MentosBehaviorScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
//		transform.Rotate (new Vector3 (1.5f, 3.0f, 4.5f) * Time.deltaTime);
	}
}
