﻿using UnityEngine;
using System.Collections;

public class BeerMovementScript : MonoBehaviour {

	private Animator anim;
	private CharacterController controller;
	public float speed = 4.0f;
	public float turnSpeed = 60.0f;
	private Vector3 moveDirection = Vector3.zero;
	public float gravity = 9.8f;
	public Transform self;
	private float jumpSpeed = 5;
	private float powerUpScalar = 1;
	private ParticleSystem particleSys;
	public float pushPower = 2.0F;

	void Awake () {
		self = transform;
	}

	// Use this for initialization
	void Start () {
		anim = GetComponent<Animator> ();
		controller = GetComponent<CharacterController> ();
		particleSys = GetComponentInChildren<ParticleSystem> ();

	}

	// Update is called once per frame
	void Update () {
		if (Input.GetMouseButtonDown (0)) {
			Ray ray = Camera.main.ScreenPointToRay (Input.mousePosition);
			RaycastHit hit;
			if (Physics.Raycast(ray, out hit)) {
				//attach to bone
				GameObject obj = hit.transform.gameObject;
				Debug.Log (obj.tag);
				Transform objTransform = obj.transform;
				objTransform.parent = self.transform;
				objTransform.localPosition = new Vector3(0.8f, 1.0f, 0.2f);
				objTransform.localRotation = Quaternion.identity;
//				objTransform.localScale = new Vector3 (0.1f, 0.1f, 0.1f);
			}
		}

	    if (Input.GetKey("w") || Input.GetKey("a") || Input.GetKey("s") || Input.GetKey("d")) {
			anim.SetBool("rolling", true);
		} else {
			anim.SetBool("rolling", false);
		}
		if (controller.isGrounded) {
			particleSys.Stop ();
			moveDirection = transform.forward * Input.GetAxis ("Vertical") * speed;
			float turn = Input.GetAxis ("Horizontal");
			transform.Rotate (0, turn * turnSpeed * Time.deltaTime, 0);
			if (Input.GetKey("space")) {
				moveDirection.y = powerUpScalar*jumpSpeed;
				particleSys.Play (); 
				}
		}
			
		moveDirection.y -= gravity * Time.deltaTime;
		controller.Move (moveDirection * Time.deltaTime);
	}

	void OnControllerColliderHit(ControllerColliderHit hit) {
		Rigidbody body = hit.collider.attachedRigidbody;
		if (body == null || body.isKinematic)
			return;

		if (hit.moveDirection.y < -0.3F)
			return;

		Vector3 pushDir = new Vector3(hit.moveDirection.x, 0, hit.moveDirection.z);
		body.velocity = pushDir * pushPower;
	}


}