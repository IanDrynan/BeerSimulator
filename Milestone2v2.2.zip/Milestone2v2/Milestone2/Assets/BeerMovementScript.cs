﻿using UnityEngine;
using System.Collections;

public class BeerMovementScript : MonoBehaviour {

	private Animator anim;
	private CharacterController controller;
	public float speed = 4.0f;
	public float turnSpeed = 60.0f;
	private Vector3 moveDirection = Vector3.zero;
	public float gravity = 9.8f;
	public Transform self;
	private float jumpSpeed = 7; 
	private float powerUpScalar = 1; //2 for mentos
	private ParticleSystem particleSys;
	public float pushPower = 2.0F;
	GameObject equippedItem;
	Vector3 equippedItemOrigPos;
	Vector3 equippedItemOrigSize;

	void Awake () {
		self = transform;
	}

	// Use this for initialization
	void Start () {
		anim = GetComponent<Animator> ();
		controller = GetComponent<CharacterController> ();
		particleSys = GetComponentInChildren<ParticleSystem> ();

	}


	// Update is called once per frame
	void Update () {
	    if (Input.GetKey("w") || Input.GetKey("a") || Input.GetKey("s") || Input.GetKey("d")) {
			anim.SetBool("rolling", true);
		} else {
			anim.SetBool("rolling", false);
		}
		if (controller.isGrounded) {
			particleSys.Stop ();
			moveDirection = transform.forward * Input.GetAxis ("Vertical") * speed;
			float turn = Input.GetAxis ("Horizontal");
			transform.Rotate (0, turn * turnSpeed * Time.deltaTime, 0);
			if (Input.GetKey("space")) {
				moveDirection.y = powerUpScalar*jumpSpeed;
				particleSys.Play (); 
				}
		}
			
		moveDirection.y -= gravity * Time.deltaTime;
		controller.Move (moveDirection * Time.deltaTime);
	}

	void LateUpdate() {
		if (Input.GetMouseButtonDown (0)) {
			Ray ray = Camera.main.ScreenPointToRay (Input.mousePosition);
			RaycastHit hit;
			if (Physics.Raycast(ray, out hit)) {
				Dequip();
				Equip(hit.transform.gameObject);
			}
		}
		else if (Input.GetMouseButtonDown(1)) {
			Dequip();
		}
	}

	void OnControllerColliderHit(ControllerColliderHit hit) {
		Rigidbody body = hit.collider.attachedRigidbody;
		if (body == null || body.isKinematic)
			return;

		if (hit.moveDirection.y < -0.3F)
			return;

		Vector3 pushDir = new Vector3(hit.moveDirection.x, 0, hit.moveDirection.z);
		body.velocity = pushDir * pushPower;
	}

    void Dequip()
    {
        if (equippedItem)
        {
            equippedItem.transform.parent = null;
            equippedItem.transform.position = equippedItemOrigPos;
			equippedItem.transform.localScale = equippedItemOrigSize;
            equippedItem.tag = "Respawn";
            equippedItem = null;
            equippedItemOrigPos = Vector3.zero;
			equippedItemOrigSize = Vector3.zero;
		
        }
    }

    void Equip(GameObject item)
    {
        // attach item to bone
        equippedItem = item;
        equippedItemOrigPos = equippedItem.transform.position;
		equippedItemOrigSize = equippedItem.transform.localScale;
        equippedItem.tag = "equipped";
        equippedItem.transform.parent = self.transform;
        equippedItem.transform.localPosition = new Vector3(0.8f, 1.0f, 0.5f);
        equippedItem.transform.localRotation = Quaternion.identity;
        equippedItem.transform.localScale = new Vector3(0.3f, 0.3f, 0.3f);
    }


}